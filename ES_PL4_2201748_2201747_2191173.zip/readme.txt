Trabalho Realizado por:
	David Marques - 2201748
	Rodrigo Nunes - 2191173
	Tomás Neves - 2201747
	
	O programa foi desenvolvido em 2 aplicações diferentes, a parte gráfica foi desenvolvida no NetBeans,
		e a parte de código foi desenvolvida no IntelliJ, para correr o programa basta abrir
		no IntelliJ e ir a pasta AutoSell-src-main-java-AutoSell-Login, ao abrir a Classe "Login" deve de
		correr o programa, de seguida é lhe apresentado um login, os utilizadores com que pode iniciar
		sessão encontram-se na classe "Login".
		
		Username: sede - Password - 123
		Username: filial1 - Password - 123
		Username: filial2 - Password - 123
		Username: filial3 - Password - 123
		Username: filial4 - Password - 123
		Username: filial5 - Password - 123



----- Casos de Uso
Adicionar venda					-Rodrigo
Adicionar compra				-Rodrigo
Verificar histórico de transações		-Rodrigo
Inserir novo Eventos				-Rodrigo
Cancelar Evento					-Rodrigo
Editar determinado Evento			-Rodrigo
Visualizar Histórico de Eventos			-Rodrigo
Estatisticas Marcas mais vendidas		-David
Estatisticas Clientes				-David
Estatisticas Feiras				-David
Estatisticas Filiais				-David
Registar Veiculo				-David
Editar Veiculo					-David
Visualizar Veiculo				-David
Remover Veiculo					-David
Reservar Veiculo				-David
Registar novo Cliente				-Tomás
Editar Cliente					-Tomás
Remover Cliente					-Tomás
Visualizar Clientes				-Tomás
Adicionar Peças					-Tomás
Editar Peças					-Tomás
Remover Peças					-Tomás
Visualizar peças em stock			-Tomás
Registar nova Filiais				-Tomás
Editar Filiais					-Tomás
Visualizar Filiais				-Tomás
Remover Filiais					-Tomás
Registar Manutenções				-David
Visualizar Manutenções				-David
Remover Manutenções				-David
Registar Preparação				-David
Editar Manutenções				-David
Login						-Rodrigo

